extends CharacterBody2D

@export var speed: float = 200.0
var last_direction: Vector2 = Vector2(0,1)

func _physics_process(delta):
	var input_vector = Vector2(
		Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"),
		Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	)

	if input_vector != Vector2.ZERO:
		input_vector = input_vector.normalized()
		velocity = input_vector * speed
		move_and_slide()
		_update_animation(input_vector, true)  # ✅ CALL function, do NOT assign
	else:
		velocity = Vector2.ZERO
		move_and_slide()
		_update_animation(Vector2.ZERO, false)  # ✅ CALL function
		

func _update_animation(direction: Vector2, walking: bool) -> void:
	if direction != Vector2.ZERO:
		last_direction = direction.normalized()

	var anim_prefix = "walk_" if walking else "idle_"
	var dir = last_direction
	var degrees = rad_to_deg(dir.angle())
	if degrees < 0:
		degrees += 360

	var anim_name: String = ""
	if degrees >= 337.5 or degrees < 22.5:
		anim_name = anim_prefix + "east"
	elif degrees < 67.5:
		anim_name = anim_prefix + "south_east"
	elif degrees < 112.5:
		anim_name = anim_prefix + "south"
	elif degrees < 157.5:
		anim_name = anim_prefix + "south_west"
	elif degrees < 202.5:
		anim_name = anim_prefix + "west"
	elif degrees < 247.5:
		anim_name = anim_prefix + "north_west"
	elif degrees < 292.5:
		anim_name = anim_prefix + "north"
	else:
		anim_name = anim_prefix + "north_east"

	$AnimatedSprite2D.play(anim_name)
